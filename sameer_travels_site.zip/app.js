
document.addEventListener("DOMContentLoaded", () => {
  const lowerSeats = document.getElementById("lower-seats");
  const upperSeats = document.getElementById("upper-seats");

  for (let i = 1; i <= 15; i++) {
    lowerSeats.innerHTML += '<label><input type="checkbox" name="seats" value="L' + i + '"/>L' + i + '</label>';
    upperSeats.innerHTML += '<label><input type="checkbox" name="seats" value="U' + i + '"/>U' + i + '</label>';
  }

  document.getElementById("bookingForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const form = e.target;
    const name = form.name.value;
    const passengers = parseInt(form.passengers.value);
    const luggage = parseFloat(form.luggage.value);
    const selectedSeats = Array.from(form.querySelectorAll("input[name='seats']:checked")).map(input => input.value);

    let seatCost = 0;
    selectedSeats.forEach(seat => {
      if (seat.endsWith("1")) seatCost += 3500; // Single
      else seatCost += 2300; // Half
    });

    const luggageCost = luggage * 20;
    const total = seatCost + luggageCost;

    document.getElementById("bill").innerHTML = `
      <h2>Bill</h2>
      <p><strong>Name:</strong> ${name}</p>
      <p><strong>Passengers:</strong> ${passengers}</p>
      <p><strong>Luggage:</strong> ${luggage} kg</p>
      <p><strong>Selected Seats:</strong> ${selectedSeats.join(", ")}</p>
      <p><strong>Seat Cost:</strong> ₹${seatCost}</p>
      <p><strong>Luggage Cost:</strong> ₹${luggageCost}</p>
      <p><strong>Total Amount:</strong> ₹${total}</p>
    `;
  });
});
